// HealthCare AI - Chart.js Configuration and Utilities

// Chart.js Global Configuration
Chart.defaults.font.family = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
Chart.defaults.font.size = 12;
Chart.defaults.color = '#6c757d';
Chart.defaults.plugins.legend.labels.usePointStyle = true;
Chart.defaults.plugins.legend.labels.padding = 20;

// Color Palettes
const ChartColors = {
    primary: '#007bff',
    secondary: '#6c757d',
    success: '#28a745',
    info: '#17a2b8',
    warning: '#ffc107',
    danger: '#dc3545',
    light: '#f8f9fa',
    dark: '#343a40',
    medical: ['#007bff', '#28a745', '#17a2b8', '#ffc107', '#fd7e14', '#6f42c1', '#e83e8c', '#20c997'],
    gradients: {
        primary: 'linear-gradient(135deg, #007bff 0%, #0056b3 100%)',
        success: 'linear-gradient(135deg, #28a745 0%, #20c997 100%)',
        info: 'linear-gradient(135deg, #17a2b8 0%, #20c997 100%)',
        warning: 'linear-gradient(135deg, #ffc107 0%, #fd7e14 100%)'
    }
};

// Chart Utilities
const ChartUtils = {
    // Generate responsive chart options
    getResponsiveOptions: function(options = {}) {
        return {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: options.showLegend !== false,
                    position: options.legendPosition || 'top',
                    labels: {
                        padding: 20,
                        usePointStyle: true,
                        font: {
                            size: 11
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    borderColor: ChartColors.primary,
                    borderWidth: 1,
                    cornerRadius: 8,
                    displayColors: true,
                    intersect: false,
                    mode: 'index'
                }
            },
            scales: options.scales || {},
            animation: {
                duration: options.reducedMotion ? 0 : 1000,
                easing: 'easeInOutQuart'
            },
            ...options
        };
    },

    // Generate color array for datasets
    generateColors: function(count, palette = 'medical') {
        const colors = ChartColors[palette] || ChartColors.medical;
        const result = [];
        
        for (let i = 0; i < count; i++) {
            result.push(colors[i % colors.length]);
        }
        
        return result;
    },

    // Create gradient background
    createGradient: function(ctx, colorStart, colorEnd, vertical = true) {
        const gradient = vertical 
            ? ctx.createLinearGradient(0, 0, 0, ctx.canvas.height)
            : ctx.createLinearGradient(0, 0, ctx.canvas.width, 0);
        
        gradient.addColorStop(0, colorStart);
        gradient.addColorStop(1, colorEnd);
        
        return gradient;
    },

    // Format date for chart labels
    formatDate: function(date, format = 'short') {
        const options = {
            short: { month: 'short', day: 'numeric' },
            long: { month: 'long', day: 'numeric', year: 'numeric' },
            monthYear: { month: 'short', year: 'numeric' }
        };
        
        return new Date(date).toLocaleDateString('en-US', options[format]);
    },

    // Animate number counting
    animateNumber: function(element, finalNumber, duration = 1000, isDecimal = false) {
        const startNumber = 0;
        const increment = finalNumber / (duration / 16);
        let currentNumber = startNumber;
        
        const timer = setInterval(() => {
            currentNumber += increment;
            if (currentNumber >= finalNumber) {
                element.textContent = isDecimal ? finalNumber.toFixed(1) : Math.floor(finalNumber);
                clearInterval(timer);
            } else {
                element.textContent = isDecimal ? currentNumber.toFixed(1) : Math.floor(currentNumber);
            }
        }, 16);
    },

    // Check for reduced motion preference
    prefersReducedMotion: function() {
        return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }
};

// Common Chart Configurations
const ChartConfigs = {
    // Line chart for progress tracking
    progressLine: function(data, options = {}) {
        return {
            type: 'line',
            data: {
                labels: data.labels,
                datasets: [{
                    label: options.label || 'Progress',
                    data: data.values,
                    borderColor: options.color || ChartColors.primary,
                    backgroundColor: options.backgroundColor || ChartColors.primary + '20',
                    tension: 0.4,
                    fill: options.fill !== false,
                    pointBackgroundColor: options.color || ChartColors.primary,
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    pointHoverRadius: 6
                }]
            },
            options: ChartUtils.getResponsiveOptions({
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                },
                elements: {
                    point: {
                        hoverBorderWidth: 3
                    }
                },
                ...options
            })
        };
    },

    // Doughnut chart for condition distribution
    conditionDoughnut: function(data, options = {}) {
        const colors = ChartUtils.generateColors(data.labels.length);
        
        return {
            type: 'doughnut',
            data: {
                labels: data.labels,
                datasets: [{
                    data: data.values,
                    backgroundColor: colors,
                    borderColor: '#ffffff',
                    borderWidth: 3,
                    hoverBorderWidth: 4
                }]
            },
            options: ChartUtils.getResponsiveOptions({
                cutout: '60%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            generateLabels: function(chart) {
                                const data = chart.data;
                                if (data.labels.length && data.datasets.length) {
                                    return data.labels.map((label, i) => {
                                        const dataset = data.datasets[0];
                                        const backgroundColor = dataset.backgroundColor[i];
                                        const value = dataset.data[i];
                                        const total = dataset.data.reduce((a, b) => a + b, 0);
                                        const percentage = ((value / total) * 100).toFixed(1);
                                        
                                        return {
                                            text: `${label} (${percentage}%)`,
                                            fillStyle: backgroundColor,
                                            strokeStyle: backgroundColor,
                                            pointStyle: 'circle'
                                        };
                                    });
                                }
                                return [];
                            }
                        }
                    }
                },
                ...options
            })
        };
    },

    // Bar chart for monthly activity
    monthlyBar: function(data, options = {}) {
        return {
            type: 'bar',
            data: {
                labels: data.labels,
                datasets: [{
                    label: options.label || 'Monthly Activity',
                    data: data.values,
                    backgroundColor: options.color || ChartColors.info + 'CC',
                    borderColor: options.color || ChartColors.info,
                    borderWidth: 2,
                    borderRadius: 8,
                    borderSkipped: false
                }]
            },
            options: ChartUtils.getResponsiveOptions({
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                },
                ...options
            })
        };
    }
};

// Chart Factory
const ChartFactory = {
    // Create a new chart instance
    create: function(canvasId, config) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) {
            console.error(`Canvas element with id '${canvasId}' not found`);
            return null;
        }

        const ctx = canvas.getContext('2d');
        
        // Apply reduced motion preferences
        if (ChartUtils.prefersReducedMotion()) {
            config.options.animation = { duration: 0 };
        }

        return new Chart(ctx, config);
    },

    // Create progress line chart
    createProgressChart: function(canvasId, data, options = {}) {
        const config = ChartConfigs.progressLine(data, options);
        return this.create(canvasId, config);
    },

    // Create condition distribution chart
    createConditionChart: function(canvasId, data, options = {}) {
        const config = ChartConfigs.conditionDoughnut(data, options);
        return this.create(canvasId, config);
    },

    // Create monthly activity chart
    createMonthlyChart: function(canvasId, data, options = {}) {
        const config = ChartConfigs.monthlyBar(data, options);
        return this.create(canvasId, config);
    }
};

// Data Processing Utilities
const DataProcessor = {
    // Process prescription data for charts
    processPrescriptionData: function(prescriptions) {
        if (!prescriptions || prescriptions.length === 0) {
            return {
                timeline: { labels: [], values: [] },
                conditions: { labels: ['No Data'], values: [1] },
                monthly: { labels: [], values: [] }
            };
        }

        // Sort prescriptions by date
        const sortedPrescriptions = prescriptions.sort((a, b) => 
            new Date(a.upload_date) - new Date(b.upload_date)
        );

        // Timeline data (cumulative)
        const timelineLabels = sortedPrescriptions.map(p => 
            ChartUtils.formatDate(p.upload_date)
        );
        const timelineValues = sortedPrescriptions.map((_, index) => index + 1);

        // Condition distribution
        const conditionCounts = {};
        sortedPrescriptions.forEach(p => {
            const condition = p.predicted_disease || 'Unknown';
            conditionCounts[condition] = (conditionCounts[condition] || 0) + 1;
        });

        // Monthly activity
        const monthlyCounts = {};
        sortedPrescriptions.forEach(p => {
            const date = new Date(p.upload_date);
            const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
            monthlyCounts[monthKey] = (monthlyCounts[monthKey] || 0) + 1;
        });

        const sortedMonths = Object.keys(monthlyCounts).sort();
        const monthlyLabels = sortedMonths.map(month => {
            const [year, monthNum] = month.split('-');
            const date = new Date(year, monthNum - 1);
            return ChartUtils.formatDate(date, 'monthYear');
        });
        const monthlyValues = sortedMonths.map(month => monthlyCounts[month]);

        return {
            timeline: {
                labels: timelineLabels,
                values: timelineValues
            },
            conditions: {
                labels: Object.keys(conditionCounts),
                values: Object.values(conditionCounts)
            },
            monthly: {
                labels: monthlyLabels,
                values: monthlyValues
            }
        };
    },

    // Calculate health metrics
    calculateMetrics: function(prescriptions) {
        if (!prescriptions || prescriptions.length === 0) {
            return {
                totalAnalyses: 0,
                dayTracking: 0,
                conditionsTracked: 0,
                averagePerDay: 0
            };
        }

        const sortedPrescriptions = prescriptions.sort((a, b) => 
            new Date(a.upload_date) - new Date(b.upload_date)
        );

        const firstDate = new Date(sortedPrescriptions[0].upload_date);
        const lastDate = new Date(sortedPrescriptions[sortedPrescriptions.length - 1].upload_date);
        const daysDiff = Math.max(1, Math.ceil((lastDate - firstDate) / (1000 * 60 * 60 * 24)) + 1);

        const uniqueConditions = new Set(
            prescriptions
                .map(p => p.predicted_disease)
                .filter(condition => condition && condition !== 'Unknown')
        );

        return {
            totalAnalyses: prescriptions.length,
            dayTracking: daysDiff,
            conditionsTracked: uniqueConditions.size,
            averagePerDay: (prescriptions.length / daysDiff).toFixed(1)
        };
    }
};

// Export for global use
window.ChartUtils = ChartUtils;
window.ChartConfigs = ChartConfigs;
window.ChartFactory = ChartFactory;
window.DataProcessor = DataProcessor;
window.ChartColors = ChartColors;

// Initialize charts when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Auto-initialize charts if data is available
    if (typeof prescriptionsData !== 'undefined' && prescriptionsData.length > 0) {
        const processedData = DataProcessor.processPrescriptionData(prescriptionsData);
        
        // Timeline Chart
        const timelineCanvas = document.getElementById('timelineChart');
        if (timelineCanvas) {
            ChartFactory.createProgressChart('timelineChart', processedData.timeline, {
                label: 'Cumulative Analyses',
                color: ChartColors.primary
            });
        }

        // Condition Chart
        const conditionCanvas = document.getElementById('conditionChart');
        if (conditionCanvas) {
            ChartFactory.createConditionChart('conditionChart', processedData.conditions);
        }

        // Monthly Chart
        const monthlyCanvas = document.getElementById('monthlyChart');
        if (monthlyCanvas) {
            ChartFactory.createMonthlyChart('monthlyChart', processedData.monthly, {
                label: 'Analyses per Month',
                color: ChartColors.info
            });
        }
    }

    // Animate stats numbers
    const statsNumbers = document.querySelectorAll('.stats-number');
    statsNumbers.forEach((element, index) => {
        const finalValue = parseFloat(element.textContent);
        if (!isNaN(finalValue)) {
            element.textContent = '0';
            setTimeout(() => {
                ChartUtils.animateNumber(
                    element, 
                    finalValue, 
                    1000, 
                    element.textContent.includes('.')
                );
            }, index * 200);
        }
    });
});

// Responsive chart handling
window.addEventListener('resize', function() {
    // Charts automatically resize with Chart.js responsive option
    // This is here for any custom responsive logic if needed
});

// Export utilities for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        ChartUtils,
        ChartConfigs,
        ChartFactory,
        DataProcessor,
        ChartColors
    };
}
