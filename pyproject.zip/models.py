from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship with prescriptions
    prescriptions = db.relationship('Prescription', backref='user', lazy=True, cascade='all, delete-orphan')
    
    def set_password(self, password):
        """Hash and set the password"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check if provided password matches the hash"""
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'

class Prescription(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    original_filename = db.Column(db.String(255), nullable=False)
    extracted_text = db.Column(db.Text)
    predicted_disease = db.Column(db.String(255))
    recommended_remedies = db.Column(db.Text)
    side_effects_warning = db.Column(db.Text)
    upload_date = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Foreign key to User
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    def __repr__(self):
        return f'<Prescription {self.filename}>'

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "upload_date": self.upload_date.isoformat() if self.upload_date else None,
            "original_filename": self.original_filename,
            "filename": self.filename,
            "predicted_disease": self.predicted_disease,
            "extracted_text": self.extracted_text
        }

class MedicineDatabase(db.Model):
    """Reference database for medicines and their properties"""
    id = db.Column(db.Integer, primary_key=True)
    medicine_name = db.Column(db.String(255), nullable=False, unique=True)
    generic_name = db.Column(db.String(255))
    category = db.Column(db.String(100))
    common_uses = db.Column(db.Text)
    side_effects = db.Column(db.Text)
    long_term_risks = db.Column(db.Text)
    
    def __repr__(self):
        return f'<Medicine {self.medicine_name}>'

class DiseaseReference(db.Model):
    """Reference database for diseases and treatments"""
    id = db.Column(db.Integer, primary_key=True)
    disease_name = db.Column(db.String(255), nullable=False, unique=True)
    symptoms = db.Column(db.Text)
    common_medicines = db.Column(db.Text)
    natural_remedies = db.Column(db.Text)
    lifestyle_recommendations = db.Column(db.Text)
    
    def __repr__(self):
        return f'<Disease {self.disease_name}>'
