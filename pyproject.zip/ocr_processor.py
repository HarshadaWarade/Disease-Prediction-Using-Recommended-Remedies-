import os
import re
import logging
import pytesseract
from PIL import Image
import fitz  # PyMuPDF
import shutil
import numpy as np

# Try to find Tesseract executable
def find_tesseract():
    """Find Tesseract executable on the system"""
    # Common Windows paths
    windows_paths = [
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        r"C:\Users\{}\AppData\Local\Tesseract-OCR\tesseract.exe".format(os.getenv('USERNAME', '')),
        r"C:\tools\tesseract\tesseract.exe",
    ]
    
    # Check if tesseract is in PATH first
    tesseract_path = shutil.which('tesseract')
    if tesseract_path:
        return tesseract_path
    
    # Check common Windows installation paths
    for path in windows_paths:
        if os.path.exists(path):
            return path
    
    # Default fallback - will fail if not found, but we handle that
    return 'tesseract'

# Set tesseract path
try:
    pytesseract.pytesseract.tesseract_cmd = find_tesseract()
    # Test if tesseract works
    pytesseract.get_tesseract_version()
    TESSERACT_AVAILABLE = True
except Exception:
    TESSERACT_AVAILABLE = False

class OCRProcessor:
    """
    OCR processor for extracting text from images and PDF files using Tesseract and PyMuPDF.
    """

    def extract_text(self, file_path: str) -> str:
        """
        Extract text from image or PDF file

        Args:
            file_path (str): Path to the file to process

        Returns:
            str: Extracted text from the file
        """
        try:
            if not os.path.exists(file_path):
                logging.error(f"File not found: {file_path}")
                return "File not found."

            file_extension = os.path.splitext(file_path)[1].lower()

            if file_extension == '.pdf':
                return self._extract_text_from_pdf(file_path)
            elif file_extension in ['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tiff']:
                return self._extract_text_from_image(file_path)
            else:
                logging.error(f"Unsupported file format: {file_extension}")
                return f"Unsupported file format: {file_extension}. Please upload PDF, PNG, JPG, or other supported image formats."

        except Exception as e:
            logging.error(f"Error extracting text from {file_path}: {e}")
            return f"Error processing file: {str(e)}"

    def _extract_text_from_image(self, image_path: str) -> str:
        """
        Extract text from image using pytesseract with enhanced preprocessing.

        Args:
            image_path (str): Path to the image file

        Returns:
            str: Extracted text
        """
        try:
            # Check if Tesseract is available
            if not TESSERACT_AVAILABLE:
                return """Tesseract OCR is not installed or not working properly on this system.

To process images, please:
1. Install Tesseract OCR from: https://github.com/UB-Mannheim/tesseract/wiki
2. Or convert your image to PDF and try again (PDF text extraction works without Tesseract)
3. Restart the application after installing Tesseract

Alternative: You can also try using online OCR tools to convert your image to text, then paste the text directly into a document for upload."""
            
            # Open and preprocess image for better OCR
            img = Image.open(image_path)
            
            # Convert to RGB if necessary
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            # Log image details
            logging.info(f"Processing image: {image_path}, Size: {img.size}, Mode: {img.mode}")
            
            # Apply image preprocessing for better OCR
            img_array = np.array(img)
            
            # Try multiple OCR configurations for better results
            ocr_configs = [
                '--psm 6',  # Uniform block of text
                '--psm 4',  # Single column of text
                '--psm 3',  # Fully automatic page segmentation
                '--psm 11', # Sparse text
                '--psm 13'  # Raw line. Treat the image as a single text line
            ]
            
            best_text = ""
            max_confidence = 0
            
            for config in ocr_configs:
                try:
                    # Get OCR data with confidence scores
                    ocr_data = pytesseract.image_to_data(img, config=config, output_type=pytesseract.Output.DICT)
                    
                    # Calculate average confidence
                    confidences = [int(conf) for conf in ocr_data['conf'] if int(conf) > 0]
                    avg_confidence = sum(confidences) / len(confidences) if confidences else 0
                    
                    # Get text with this configuration
                    text = pytesseract.image_to_string(img, config=config)
                    
                    # Use this result if it has better confidence and reasonable length
                    if avg_confidence > max_confidence and len(text.strip()) > 5:  # Lowered threshold
                        max_confidence = avg_confidence
                        best_text = text
                        
                except Exception as config_e:
                    logging.warning(f"OCR config {config} failed: {config_e}")
                    continue
            
            # Fallback to simple OCR if no good result found
            if not best_text.strip():
                try:
                    best_text = pytesseract.image_to_string(img)
                    logging.info("Using fallback OCR method")
                except Exception as fallback_e:
                    logging.error(f"Fallback OCR failed: {fallback_e}")
                    return f"OCR processing failed: {fallback_e}"
            
            # Clean up the extracted text
            best_text = self._clean_extracted_text(best_text)
            
            logging.info(f"Extracted text from image: {len(best_text)} characters (confidence: {max_confidence:.1f})")
            
            # Return message if no text found
            if not best_text.strip():
                return "No text could be detected in this image. Please ensure the image is clear and contains readable text."
            
            return best_text
            
        except Exception as e:
            logging.error(f"Error extracting text from image {image_path}: {e}")
            return f"Error processing image: {str(e)}"

    def _extract_text_from_pdf(self, pdf_path: str) -> str:
        """
        Extract text from PDF file using PyMuPDF with improved processing.

        Args:
            pdf_path (str): Path to the PDF file

        Returns:
            str: Extracted text
        """
        try:
            text = ""
            with fitz.open(pdf_path) as doc:
                for page_num, page in enumerate(doc):
                    # Extract text with different methods for better accuracy
                    page_text = page.get_text()
                    
                    # If text extraction is poor, try OCR on the page image
                    if len(page_text.strip()) < 50:
                        try:
                            # Convert PDF page to image and apply OCR
                            pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))  # 2x zoom for better quality
                            img_data = pix.tobytes("png")
                            
                            # Save temporary image
                            temp_img_path = f"temp_page_{page_num}.png"
                            with open(temp_img_path, "wb") as img_file:
                                img_file.write(img_data)
                            
                            # Apply OCR to the image
                            img = Image.open(temp_img_path)
                            ocr_text = pytesseract.image_to_string(img, config='--psm 6')
                            
                            # Use OCR text if it's better than direct extraction
                            if len(ocr_text.strip()) > len(page_text.strip()):
                                page_text = ocr_text
                            
                            # Clean up temporary file
                            os.remove(temp_img_path)
                            
                        except Exception as ocr_e:
                            logging.warning(f"OCR fallback failed for page {page_num}: {ocr_e}")
                    
                    text += page_text + "\n"
            
            # Clean up the extracted text
            text = self._clean_extracted_text(text)
            logging.info(f"Extracted text from PDF: {len(text)} characters")
            return text
        except Exception as e:
            logging.error(f"Error extracting text from PDF {pdf_path}: {e}")
            return ""
    
    def _clean_extracted_text(self, text: str) -> str:
        """
        Clean and preprocess extracted text for better analysis.
        
        Args:
            text (str): Raw extracted text
            
        Returns:
            str: Cleaned text
        """
        # Remove extra whitespace and normalize
        text = " ".join(text.split())
        
        # Remove common OCR artifacts
        text = re.sub(r'[^\w\s\-\.\,\:\;\/\(\)]', ' ', text)
        
        # Fix common OCR errors in medical terms
        medical_corrections = {
            r'\bmg\b': 'mg',  # milligrams
            r'\bml\b': 'ml',  # milliliters
            r'\btab\b': 'tablet',
            r'\bcap\b': 'capsule',
            r'\bbd\b': 'twice daily',
            r'\bod\b': 'once daily',
            r'\btid\b': 'three times daily',
            r'\bqid\b': 'four times daily',
            r'\bprn\b': 'as needed',
            r'\bpo\b': 'by mouth',
            r'\biv\b': 'intravenous',
            r'\bim\b': 'intramuscular',
            r'\bsc\b': 'subcutaneous'
        }
        
        for pattern, replacement in medical_corrections.items():
            text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
        
        return text

    def validate_extracted_text(self, text: str) -> bool:
        """
        Validate if extracted text seems to be a valid prescription

        Args:
            text (str): Extracted text to validate

        Returns:
            bool: True if text seems valid, False otherwise
        """
        if not text or len(text.strip()) < 10:
            return False

        prescription_keywords = [
            'mg', 'ml', 'tablet', 'capsule', 'dose', 'daily', 'twice', 'once',
            'morning', 'evening', 'before', 'after', 'meal', 'rx', 'prescription',
            'patient', 'doctor', 'dr.', 'take', 'sig', 'qty', 'refill'
        ]

        text_lower = text.lower()
        keyword_count = sum(1 for keyword in prescription_keywords if keyword in text_lower)

        return keyword_count >= 3