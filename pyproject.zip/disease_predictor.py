import re
import logging
from typing import Dict, List
from rapidfuzz import fuzz
import google.generativeai as genai
import os

genai.configure(api_key=os.getenv("GEMINI_API_KEY"))


class DiseasePredictor:
    def __init__(self):
        self.medicine_disease_map = {
            # Pain/Inflammation - Expanded
            'ibuprofen': 'Pain/Inflammation',
            'naproxen': 'Pain/Inflammation',
            'diclofenac': 'Pain/Inflammation',
            'aspirin': 'Pain/Inflammation',
            'indomethacin': 'Pain/Inflammation',
            'piroxicam': 'Pain/Inflammation',
            'etoricoxib': 'Pain/Inflammation',
            'nimesulide': 'Pain/Inflammation',
            'aceclofenac': 'Pain/Inflammation',
            'meloxicam': 'Pain/Inflammation',

            # Fever - Expanded
            'acetaminophen': 'Fever',
            'paracetamol': 'Fever',
            'panadol': 'Fever',
            'tylenol': 'Fever',
            'crocin': 'Fever',
            'dolo': 'Fever',

            # Cold/Flu - Expanded
            'chlorpheniramine': 'Cold',
            'phenylephrine': 'Cold',
            'pseudoephedrine': 'Cold',
            'diphenhydramine': 'Cold',
            'brompheniramine': 'Cold',
            'triprolidine': 'Cold',

            # Cough - Expanded
            'dextromethorphan': 'Cough',
            'guaifenesin': 'Cough',
            'codeine': 'Cough',
            'bromhexine': 'Cough',
            'ambroxol': 'Cough',
            'terbutaline': 'Cough',
            'salbutamol': 'Cough',

            # Headache/Migraine - Expanded
            'sumatriptan': 'Migraine',
            'rizatriptan': 'Migraine',
            'zolmitriptan': 'Migraine',
            'ergotamine': 'Migraine',
            'propranolol': 'Migraine',

            # Gastrointestinal - Expanded
            'omeprazole': 'Acidity',
            'pantoprazole': 'Acidity',
            'ranitidine': 'Acidity',
            'famotidine': 'Acidity',
            'lansoprazole': 'Acidity',
            'esomeprazole': 'Acidity',
            'rabeprazole': 'Acidity',
            'domperidone': 'Acidity',
            'ondansetron': 'Nausea',
            'metoclopramide': 'Nausea',

            # Constipation/Diarrhea
            'lactulose': 'Constipation',
            'ispaghula': 'Constipation',
            'bisacodyl': 'Constipation',
            'docusate': 'Constipation',
            'loperamide': 'Diarrhea',
            'racecadotril': 'Diarrhea',
            'ofloxacin': 'Bacterial Infection',

            # Cardiovascular - Expanded
            'amlodipine': 'High BP',
            'lisinopril': 'High BP',
            'metoprolol': 'High BP',
            'atenolol': 'High BP',
            'losartan': 'High BP',
            'valsartan': 'High BP',
            'ramipril': 'High BP',
            'enalapril': 'High BP',
            'nifedipine': 'High BP',
            'telmisartan': 'High BP',
            'olmesartan': 'High BP',
            'carvedilol': 'Heart Disease',
            'digoxin': 'Heart Disease',
            'warfarin': 'Blood Clots',
            'clopidogrel': 'Heart Disease',

            # Diabetes - Expanded
            'metformin': 'Diabetes',
            'insulin': 'Diabetes',
            'glipizide': 'Diabetes',
            'glyburide': 'Diabetes',
            'pioglitazone': 'Diabetes',
            'sitagliptin': 'Diabetes',
            'glimepiride': 'Diabetes',
            'empagliflozin': 'Diabetes',
            'dapagliflozin': 'Diabetes',
            'liraglutide': 'Diabetes',
            'repaglinide': 'Diabetes',

            # Respiratory - Expanded
            'albuterol': 'Asthma',
            'montelukast': 'Asthma',
            'budesonide': 'Asthma',
            'prednisone': 'Asthma',
            'fluticasone': 'Asthma',
            'beclomethasone': 'Asthma',
            'theophylline': 'Asthma',
            'ipratropium': 'Asthma',
            'formoterol': 'Asthma',
            'salmeterol': 'Asthma',

            # Allergy - Expanded
            'cetirizine': 'Allergy',
            'loratadine': 'Allergy',
            'fexofenadine': 'Allergy',
            'desloratadine': 'Allergy',
            'levocetirizine': 'Allergy',
            'hydroxyzine': 'Allergy',
            'promethazine': 'Allergy',

            # Thyroid
            'levothyroxine': 'Thyroid (Hypo)',
            'liothyronine': 'Thyroid (Hypo)',
            'methimazole': 'Thyroid (Hyper)',
            'propylthiouracil': 'Thyroid (Hyper)',

            # Musculoskeletal - Expanded
            'baclofen': 'Back Pain',
            'cyclobenzaprine': 'Back Pain',
            'methocarbamol': 'Back Pain',
            'tizanidine': 'Back Pain',
            'celecoxib': 'Joint Pain',
            'glucosamine': 'Joint Pain',
            'chondroitin': 'Joint Pain',

            # Mental Health - Expanded
            'sertraline': 'Depression',
            'fluoxetine': 'Depression',
            'paroxetine': 'Depression',
            'citalopram': 'Depression',
            'escitalopram': 'Depression',
            'venlafaxine': 'Depression',
            'duloxetine': 'Depression',
            'lorazepam': 'Anxiety',
            'alprazolam': 'Anxiety',
            'clonazepam': 'Anxiety',
            'diazepam': 'Anxiety',
            'buspirone': 'Anxiety',
            'zolpidem': 'Insomnia',
            'zopiclone': 'Insomnia',
            'melatonin': 'Insomnia',

            # Antibiotics - Infection
            'amoxicillin': 'Bacterial Infection',
            'azithromycin': 'Bacterial Infection',
            'ciprofloxacin': 'Bacterial Infection',
            'doxycycline': 'Bacterial Infection',
            'cephalexin': 'Bacterial Infection',
            'clindamycin': 'Bacterial Infection',
            'erythromycin': 'Bacterial Infection',
            'levofloxacin': 'Bacterial Infection',
            'trimethoprim': 'UTI',
            'nitrofurantoin': 'UTI',

            # Other Common Conditions
            'minoxidil': 'Hair Fall',
            'finasteride': 'Hair Fall',
            'orlistat': 'Obesity',
            'sibutramine': 'Obesity',
            'ferrous': 'Anemia',
            'folic': 'Anemia',
            'vitamin': 'Nutritional Deficiency',
            'calcium': 'Bone Health',
            'cholecalciferol': 'Vitamin D Deficiency',
        }

        self.disease_remedies = {
            'Pain/Inflammation': {
                'natural_remedies': ['Ice packs', 'Heat pads', 'Stretching', 'Turmeric'],
                'lifestyle_recommendations': ['Posture care', 'Low-impact exercise', 'Sleep well']
            },
            'Fever': {
                'natural_remedies': ['Ginger tea', 'Hydration', 'Basil leaves'],
                'lifestyle_recommendations': ['Rest', 'Stay cool', 'Drink fluids']
            },
            'Cold': {
                'natural_remedies': ['Steam inhalation', 'Honey & lemon', 'Ginger'],
                'lifestyle_recommendations': ['Avoid cold drinks', 'Stay warm', 'Use humidifier']
            },
            'Cough': {
                'natural_remedies': ['Tulsi leaves', 'Honey', 'Licorice root'],
                'lifestyle_recommendations': ['Avoid dust/smoke', 'Warm fluids', 'Voice rest']
            },
            'Migraine': {
                'natural_remedies': ['Peppermint oil', 'Cold compress', 'Ginger'],
                'lifestyle_recommendations': ['Avoid triggers', 'Sleep on schedule', 'Stress relief']
            },
            'Acidity': {
                'natural_remedies': ['Buttermilk', 'Fennel seeds', 'Coconut water'],
                'lifestyle_recommendations': ['Avoid spicy food', 'Eat small meals', 'Sleep upright']
            },
            'High BP': {
                'natural_remedies': ['Garlic', 'Beetroot juice', 'Hibiscus tea'],
                'lifestyle_recommendations': ['Low salt diet', 'Exercise', 'Stress management']
            },
            'Diabetes': {
                'natural_remedies': ['Fenugreek seeds', 'Bitter gourd juice', 'Amla'],
                'lifestyle_recommendations': ['Low carb diet', 'Exercise', 'Regular monitoring']
            },
            'Asthma': {
                'natural_remedies': ['Honey steam', 'Turmeric milk', 'Ginger tea'],
                'lifestyle_recommendations': ['Avoid triggers', 'Clean environment', 'Breathing exercises']
            },
            'Allergy': {
                'natural_remedies': ['Quercetin', 'Local honey', 'Nettle tea'],
                'lifestyle_recommendations': ['Avoid allergens', 'Clean environment', 'Healthy diet']
            }
        }

        self.long_term_side_effects = {
            'High BP': 'May affect kidney function. Regular tests advised.',
            'Diabetes': 'Watch B12 levels with metformin. Kidney checks needed.',
            'Pain/Inflammation': 'NSAIDs can harm kidneys/stomach. Use sparingly.',
            'Acidity': 'PPI overuse can reduce nutrient absorption.',
            'Depression': 'Mood monitoring and follow-ups needed.'
        }

    def extract_medicines(self, text: str) -> List[str]:
        """
        Enhanced medicine extraction with better pattern matching and context analysis.
        """
        text_lower = text.lower()
        found_medicines = []
        
        # Common medicine name patterns with dosage
        medicine_patterns = [
            r'\b(\w+)\s*\d+\s*mg\b',  # Medicine + dosage
            r'\b(\w+)\s*\d+\s*ml\b',  # Medicine + volume
            r'\btab\s+(\w+)\b',       # Tab + medicine name
            r'\bcap\s+(\w+)\b',       # Cap + medicine name
            r'\binj\s+(\w+)\b',       # Injection + medicine name
            r'\bsyr\s+(\w+)\b',       # Syrup + medicine name
        ]
        
        # Extract medicines using patterns
        for pattern in medicine_patterns:
            matches = re.findall(pattern, text_lower)
            for match in matches:
                if len(match) > 3:  # Avoid short/noise matches
                    found_medicines.append(match)
        
        # Also check for known medicines in the database
        for med in self.medicine_disease_map:
            # Use word boundaries and fuzzy matching
            words = text_lower.split()
            for word in words:
                # Clean word of punctuation
                clean_word = re.sub(r'[^\w]', '', word)
                if len(clean_word) > 3:
                    similarity = fuzz.ratio(clean_word, med)
                    if similarity > 80:  # Lowered threshold for better matching
                        found_medicines.append(med)
                        break
        
        return list(set(found_medicines))

    def predict_disease(self, extracted_text: str) -> Dict[str, str]:
        try:
            # Enhanced text preprocessing
            processed_text = self._preprocess_text(extracted_text)
            
            # Extract medicines with improved logic
            medicines = self.extract_medicines(processed_text)
            
            # Use Gemini AI for better disease prediction if no medicines found
            if not medicines:
                gemini_analysis = self.gemini_advanced_analysis(extracted_text)
                predicted_disease = self._extract_disease_from_gemini(gemini_analysis)
                
                return {
                    'disease': predicted_disease,
                    'remedies': self._get_remedies(predicted_disease),
                    'side_effects': self._get_side_effects_warning(predicted_disease),
                    'extracted_medicines': [],
                    'gemini_summary': gemini_analysis,
                    'progress_chart_data': self.generate_progress_chart_data(predicted_disease)
                }

            # Improved disease prediction using multiple factors
            disease_confidence = {}
            
            # Factor 1: Medicine-based prediction
            for medicine in medicines:
                disease = self.medicine_disease_map.get(medicine)
                if disease:
                    disease_confidence[disease] = disease_confidence.get(disease, 0) + 2
            
            # Factor 2: Symptom/context analysis from Gemini
            gemini_analysis = self.gemini_advanced_analysis(extracted_text)
            gemini_disease = self._extract_disease_from_gemini(gemini_analysis)
            if gemini_disease and gemini_disease != "Unable to determine":
                disease_confidence[gemini_disease] = disease_confidence.get(gemini_disease, 0) + 3
            
            # Factor 3: Text pattern analysis
            pattern_disease = self._analyze_text_patterns(processed_text)
            if pattern_disease:
                disease_confidence[pattern_disease] = disease_confidence.get(pattern_disease, 0) + 1
            
            # Select disease with highest confidence
            if disease_confidence:
                predicted_disease = max(disease_confidence, key=disease_confidence.get)
            else:
                predicted_disease = gemini_disease if gemini_disease else 'Unable to identify specific condition'

            return {
                'disease': predicted_disease,
                'remedies': self._get_remedies(predicted_disease),
                'side_effects': self._get_side_effects_warning(predicted_disease),
                'extracted_medicines': medicines,
                'gemini_summary': gemini_analysis,
                'progress_chart_data': self.generate_progress_chart_data(predicted_disease)
            }

        except Exception as e:
            logging.error(f"Disease prediction error: {e}")
            return {
                'disease': 'Error occurred during analysis',
                'remedies': 'Please consult a healthcare provider.',
                'side_effects': 'Unable to determine at this time.',
                'extracted_medicines': [],
                'gemini_summary': 'Analysis failed due to technical issues.',
                'progress_chart_data': {}
            }
    
    def _preprocess_text(self, text: str) -> str:
        """
        Preprocess extracted text for better analysis.
        """
        # Normalize whitespace
        text = " ".join(text.split())
        
        # Convert to lowercase for processing
        return text.lower()
    
    def _extract_disease_from_gemini(self, gemini_response: str) -> str:
        """
        Extract disease prediction from Gemini AI response.
        """
        if not gemini_response:
            return "Unable to determine"
        
        # Look for disease keywords in Gemini response
        response_lower = gemini_response.lower()
        
        # Check for diseases mentioned in our database
        mentioned_diseases = []
        for disease in self.disease_remedies.keys():
            if disease.lower() in response_lower:
                mentioned_diseases.append(disease)
        
        if mentioned_diseases:
            return mentioned_diseases[0]  # Return first mentioned disease
        
        # Look for common medical condition patterns
        condition_patterns = [
            r'condition.*?:?\s*([^.\n]+)',
            r'diagnosis.*?:?\s*([^.\n]+)',
            r'likely.*?:?\s*([^.\n]+)',
            r'suggests.*?:?\s*([^.\n]+)'
        ]
        
        for pattern in condition_patterns:
            match = re.search(pattern, response_lower)
            if match:
                potential_disease = match.group(1).strip()
                if len(potential_disease) > 3 and len(potential_disease) < 50:
                    return potential_disease.title()
        
        return "Unable to determine"
    
    def _analyze_text_patterns(self, text: str) -> str:
        """
        Analyze text patterns to help identify conditions.
        """
        # Common medical condition indicators
        pattern_indicators = {
            'diabetes': ['glucose', 'sugar', 'insulin', 'metformin', 'diabetic'],
            'hypertension': ['blood pressure', 'bp', 'amlodipine', 'lisinopril', 'hypertension'],
            'pain/inflammation': ['pain', 'ache', 'inflammation', 'ibuprofen', 'diclofenac'],
            'fever': ['fever', 'temperature', 'paracetamol', 'acetaminophen'],
            'cold': ['cold', 'cough', 'runny nose', 'congestion'],
            'acidity': ['acidity', 'heartburn', 'omeprazole', 'pantoprazole', 'antacid']
        }
        
        for condition, indicators in pattern_indicators.items():
            score = sum(1 for indicator in indicators if indicator in text)
            if score >= 2:  # Require at least 2 indicators
                return condition.title()
        
        return None

    def _get_remedies(self, disease: str) -> str:
        remedies_data = self.disease_remedies.get(disease, {})
        if not remedies_data:
            return "General tips: Healthy lifestyle, follow prescriptions, regular checkups."

        text = f"Remedies for {disease}:\n\n"
        if 'natural_remedies' in remedies_data:
            text += "Natural Remedies:\n"
            for r in remedies_data['natural_remedies']:
                text += f"• {r}\n"
        if 'lifestyle_recommendations' in remedies_data:
            text += "\nLifestyle:\n"
            for l in remedies_data['lifestyle_recommendations']:
                text += f"• {l}\n"

        return text + "\n⚠️ Consult doctor before changing anything."

    def _get_side_effects_warning(self, disease: str) -> str:
        warning = self.long_term_side_effects.get(disease)
        return f"⚠️ {warning}" if warning else "⚠️ Regular checkups are advised for long-term medication."

    def gemini_advanced_analysis(self, extracted_text: str) -> str:
        try:
            model = genai.GenerativeModel('gemini-2.0-flash-exp')
            
            # Enhanced prompt for better disease prediction
            prompt = f"""
            You are an expert medical AI assistant. Analyze this prescription/medical text and provide a detailed analysis.

            PRESCRIPTION TEXT:
            {extracted_text}

            Please provide:
            1. PRIMARY CONDITION: What medical condition is most likely being treated?
            2. MEDICINES IDENTIFIED: List the medications you can identify
            3. ANALYSIS: Brief explanation of the treatment approach
            4. CONFIDENCE: How confident are you in this assessment (High/Medium/Low)

            Focus on accuracy and be specific about the medical condition. If you cannot determine the condition clearly, say "Unable to determine clearly" and explain why.

            Keep your response concise but informative.
            """
            
            response = model.generate_content(prompt)
            return response.text.strip()
            
        except Exception as e:
            logging.error(f"Gemini API error: {e}")
            try:
                # Fallback to older model if new one fails
                model = genai.GenerativeModel('gemini-pro')
                prompt = (
                    "You are a healthcare assistant. Analyze the following prescription text and identify the primary medical condition being treated. "
                    "Be specific and mention the exact condition name.\n\n"
                    f"Prescription:\n{extracted_text}\n\n"
                    "Primary Condition:"
                )
                response = model.generate_content(prompt)
                return response.text.strip()
            except Exception as fallback_e:
                logging.error(f"Gemini fallback error: {fallback_e}")
                return "⚠️ Advanced analysis not available right now."

    def generate_progress_chart_data(self, disease: str) -> Dict[str, int]:
        if disease in self.disease_remedies:
            return {
                "Week 1": 80,
                "Week 2": 65,
                "Week 3": 50,
                "Week 4": 35,
                "Week 5": 20,
                "Week 6": 10,
            }
        return {}
