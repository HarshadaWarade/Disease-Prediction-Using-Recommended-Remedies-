import os
from dotenv import load_dotenv
import google.generativeai as genai

import logging
from datetime import datetime
from flask import render_template, request, redirect, url_for, flash, session, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
from werkzeug.exceptions import RequestEntityTooLarge
from markupsafe import Markup

from app import app, db
from models import User, Prescription, MedicineDatabase, DiseaseReference
from ocr_processor import OCRProcessor
from disease_predictor import DiseasePredictor

load_dotenv()
genai.configure(api_key=os.getenv("AIzaSyAa0dB1iwJsv1EoFo0UG0uVaFUFC8I9G1w"))

# Example model
model = genai.GenerativeModel('gemini-2.5-pro')

def get_alternative_medicines(symptoms_text):
    response = model.generate_content(
        f"Suggest alternative medicines for the following prescription or symptoms:\n{symptoms_text}"
    )
    return response.text.strip()
# Initialize processors
ocr_processor = OCRProcessor()
disease_predictor = DiseasePredictor()

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'pdf'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    """Home page"""
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """User registration"""
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        # Validation
        if not username or not email or not password:
            flash('All fields are required.', 'error')
            return render_template('register.html')
        
        if password != confirm_password:
            flash('Passwords do not match.', 'error')
            return render_template('register.html')
        
        if len(password) < 6:
            flash('Password must be at least 6 characters long.', 'error')
            return render_template('register.html')
        
        # Check if user already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists.', 'error')
            return render_template('register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered.', 'error')
            return render_template('register.html')
        
        # Create new user
        user = User(username=username, email=email)
        user.set_password(password)
        
        try:
            db.session.add(user)
            db.session.commit()
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            logging.error(f"Registration error: {e}")
            flash('Registration failed. Please try again.', 'error')
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login"""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if not username or not password:
            flash('Please enter both username and password.', 'error')
            return render_template('login.html')
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user, remember=True)
            flash(f'Welcome back, {user.username}!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password.', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    """User logout"""
    logout_user()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    """User dashboard"""
    recent_prescriptions = Prescription.query.filter_by(user_id=current_user.id)\
                                           .order_by(Prescription.upload_date.desc())\
                                           .limit(5)\
                                           .all()
    
    total_prescriptions = Prescription.query.filter_by(user_id=current_user.id).count()
    
    return render_template('dashboard.html', 
                         recent_prescriptions=recent_prescriptions,
                         total_prescriptions=total_prescriptions)

@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload_prescription():
    """Upload and process prescription"""
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file selected.', 'error')
            return redirect(request.url)
        
        file = request.files['file']
        
        if file.filename == '':
            flash('No file selected.', 'error')
            return redirect(request.url)
        
        if file and allowed_file(file.filename):
            try:
                filename = secure_filename(file.filename)
                # Create unique filename to avoid conflicts
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_')
                unique_filename = timestamp + filename
                
                # Enhanced logging for debugging
                logging.info(f"Processing file: {file.filename} (size: {len(file.read())} bytes)")
                file.seek(0)  # Reset file pointer after reading size
                
                # Save uploaded file
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
                file.save(filepath)
                logging.info(f"File saved to: {filepath}")
                
                # Extract text with detailed logging
                logging.info(f"Starting OCR extraction for: {unique_filename}")
                extracted_text = ocr_processor.extract_text(filepath)
                logging.info(f"OCR completed. Extracted {len(extracted_text)} characters")
                
                # Log first 200 characters of extracted text for debugging
                preview_text = extracted_text[:200] + "..." if len(extracted_text) > 200 else extracted_text
                logging.info(f"Extracted text preview: {preview_text}")
                
                # Check if OCR failed or returned error messages
                if not extracted_text.strip() or extracted_text.startswith("Tesseract OCR is not installed") or extracted_text.startswith("Error processing") or extracted_text.startswith("No text could be detected"):
                    # Use the extracted_text as the error message if it contains error information
                    error_message = extracted_text.strip() if extracted_text.strip() else 'No text could be extracted from the document. Please ensure the document is clear and contains readable text.'
                    
                    # Add setup guide link for Tesseract issues
                    if "Tesseract OCR is not installed" in error_message:
                        flash(Markup(f'{error_message} <br><br><a href="/ocr-setup" class="btn btn-sm btn-info"><i class="fas fa-cog me-1"></i>Setup Guide</a>'), 'error')
                    else:
                        flash(error_message, 'error')
                    
                    os.remove(filepath)  # Clean up
                    return redirect(request.url)
                
                # Enhanced disease prediction with logging
                logging.info("Starting disease prediction analysis")
                prediction_result = disease_predictor.predict_disease(extracted_text)
                logging.info(f"Disease prediction completed: {prediction_result.get('disease')}")
                logging.info(f"Extracted medicines: {prediction_result.get('extracted_medicines')}")
                
                # Create prescription record
                prescription = Prescription(
                    filename=unique_filename,
                    original_filename=file.filename,
                    extracted_text=extracted_text,
                    predicted_disease=prediction_result.get('disease'),
                    recommended_remedies=prediction_result.get('remedies'),
                    side_effects_warning=prediction_result.get('side_effects'),
                    user_id=current_user.id
                )
                
                db.session.add(prescription)
                db.session.commit()
                logging.info(f"Prescription record created with ID: {prescription.id}")
                
                flash(f'Prescription processed successfully! Predicted condition: {prediction_result.get("disease")}', 'success')
                return redirect(url_for('view_results', prescription_id=prescription.id))
                
            except RequestEntityTooLarge:
                flash('File too large. Maximum size is 16MB.', 'error')
            except Exception as e:
                logging.error(f"Upload processing error: {e}")
                flash('Error processing file. Please try again.', 'error')
                # Clean up file if it exists
                if 'filepath' in locals() and os.path.exists(filepath):
                    os.remove(filepath)
        else:
            flash('Invalid file type. Please upload PNG, JPG, JPEG, GIF, or PDF files only.', 'error')
    
    return render_template('upload.html')

@app.route('/results/<int:prescription_id>')
@login_required
def view_results(prescription_id):
    """View prescription analysis results"""
    prescription = Prescription.query.filter_by(id=prescription_id, user_id=current_user.id).first_or_404()
    return render_template('results.html', prescription=prescription)

@app.route('/progress')
@login_required
def progress():
    """View progress and health tracking"""
    prescriptions = Prescription.query.filter_by(user_id=current_user.id).order_by(Prescription.upload_date.asc()).all()
    prescriptions_dict = [p.to_dict() for p in prescriptions]

    # Ensure upload_date is in datetime format (some templates expect datetime)
    for p in prescriptions_dict:
        if isinstance(p['upload_date'], str):
            try:
                p['upload_date'] = datetime.strptime(p['upload_date'], '%Y-%m-%d')
            except:
                try:
                    p['upload_date'] = datetime.strptime(p['upload_date'], '%Y-%m-%d %H:%M:%S')
                except:
                    p['upload_date'] = datetime.now()

    return render_template('progress.html', prescriptions=prescriptions_dict)


@app.route('/api/chart_data')
@login_required
def chart_data():
    """API endpoint for chart data"""
    prescriptions = Prescription.query.filter_by(user_id=current_user.id)\
                                    .order_by(Prescription.upload_date)\
                                    .all()
    
    # Prepare data for charts
    dates = []
    diseases = []
    
    for prescription in prescriptions:
        dates.append(prescription.upload_date.strftime('%Y-%m-%d'))
        diseases.append(prescription.predicted_disease or 'Unknown')
    
    return jsonify({
        'dates': dates,
        'diseases': diseases,
        'total_count': len(prescriptions)
    })

@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500

@app.route('/debug/<int:prescription_id>')
@login_required
def debug_prescription(prescription_id):
    """Debug route to show detailed analysis of a prescription"""
    prescription = Prescription.query.get_or_404(prescription_id)
    
    # Ensure user can only see their own prescriptions
    if prescription.user_id != current_user.id:
        flash('Access denied.', 'error')
        return redirect(url_for('dashboard'))
    
    # Re-analyze the extracted text for debugging
    if prescription.extracted_text:
        prediction_result = disease_predictor.predict_disease(prescription.extracted_text)
        
        debug_info = {
            'extracted_text': prescription.extracted_text,
            'extracted_medicines': prediction_result.get('extracted_medicines', []),
            'gemini_analysis': prediction_result.get('gemini_summary', ''),
            'predicted_disease': prediction_result.get('disease'),
            'confidence_factors': {
                'medicine_count': len(prediction_result.get('extracted_medicines', [])),
                'text_length': len(prescription.extracted_text),
                'has_gemini_analysis': bool(prediction_result.get('gemini_summary'))
            }
        }
        
        return render_template('debug.html', 
                             prescription=prescription, 
                             debug_info=debug_info)
    else:
        flash('No extracted text available for analysis.', 'error')
        return redirect(url_for('dashboard'))

@app.route('/test-ocr', methods=['GET', 'POST'])
@login_required
def test_ocr():
    """Test OCR functionality with detailed output"""
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file selected', 'error')
            return redirect(request.url)
        
        file = request.files['file']
        if file.filename == '':
            flash('No file selected', 'error')
            return redirect(request.url)
        
        if file and allowed_file(file.filename):
            try:
                # Save file temporarily
                filename = secure_filename(file.filename)
                temp_path = os.path.join(app.config['UPLOAD_FOLDER'], f"test_{filename}")
                file.save(temp_path)
                
                # Test OCR extraction
                extracted_text = ocr_processor.extract_text(temp_path)
                
                # Test disease prediction
                prediction_result = disease_predictor.predict_disease(extracted_text)
                
                # Clean up temp file
                os.remove(temp_path)
                
                test_results = {
                    'filename': filename,
                    'extracted_text': extracted_text,
                    'text_length': len(extracted_text),
                    'predicted_disease': prediction_result.get('disease'),
                    'extracted_medicines': prediction_result.get('extracted_medicines', []),
                    'gemini_analysis': prediction_result.get('gemini_summary', ''),
                    'remedies': prediction_result.get('remedies', ''),
                    'side_effects': prediction_result.get('side_effects', '')
                }
                
                return render_template('test_ocr.html', results=test_results)
                
            except Exception as e:
                logging.error(f"OCR test error: {e}")
                flash(f'Error testing OCR: {str(e)}', 'error')
                return redirect(request.url)
    
    return render_template('test_ocr.html')

@app.route('/ocr-setup')
@login_required
def ocr_setup():
    """OCR Setup guide for users"""
    return render_template('ocr_setup.html')